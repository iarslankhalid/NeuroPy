def NeuralNetworks():
    print("This is neural network library made by arslan.")